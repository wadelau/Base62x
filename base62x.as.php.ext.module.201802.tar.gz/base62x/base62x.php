<?php

include_once("base62x.class.php");
//- http://ahungry.com/blog/2016-09-29-Creating-a-php-7-extension.html

$br = (php_sapi_name() == "cli")? "":"<br>";

if(!extension_loaded('base62x')) {
	dl('base62x.' . PHP_SHLIB_SUFFIX);
}
$module = 'base62x';
$functions = get_extension_funcs($module);
echo "Functions available in the test extension:$br\n";
foreach($functions as $func) {
    echo $func."$br\n";
}
echo "$br\n";
$function = 'confirm_' . $module . '_compiled';
if (extension_loaded($module)) {
	$str = $function($module);
} else {
	$str = "Module $module is not compiled into PHP";
}
echo "$str\n";

$s0 = confirm_base62x_compiled("a");
$s = base62x_encode($n=rand(1000, 999999).'abcd'.rand(1000, 999999));
$s2 = Base62x::decode($s); 

print "n:$n,base62x returned:[$s] s2:[$s2] s0:[$s0]\n";

?>
