<?php
/*
 * Base62 encode and decode with gmp support
 * Some one, refinded and encapsulated by liuzhenxing@pbtt
 * Some day
 * Some version
 * Alternative replacement is https://github.com/wadelau/Base62x with bits manipulations
 */

#include_once("class/base62x.class.php");
include_once("base62x.class.php");

class Base62{

    # variables
    const pad62 = 'B62.';
	const pad62x = 'B62x.'; # with encrypt since Thu, 8 Dec 2016 11:20:24 +0800
	const pad62zex = 'E62x.'; # zip, encrypt and base62x
    
    # constructors
    
    # methods
        
    # encode
    public static function encode($data) {
        $outstring = '';
        $pad62 =''; self::pad62;
        $l = strlen($data);
        for ($i = 0; $i < $l; $i += 8) {
            $chunk = substr($data, $i, 8);
            $outlen = ceil((strlen($chunk) * 8)/6); //8bit/char in, 6bits/char out, round up
            $x = bin2hex($chunk);  //gmp won't convert from binary, so go via hex
            $w = gmp_strval(gmp_init(ltrim($x, '0'), 16), 62); //gmp doesn't like leading 0s
            $pad = str_pad($w, $outlen, '0', STR_PAD_LEFT);
            $outstring .= $pad;
        }
        return $pad62.$outstring;
    }

    # decode
    public static function decode($data) {
        $outstring = '';
        $pad62 = self::pad62;
        if(strpos($data,$pad62) === 0){
            $data = substr($data, strlen($pad62));
        }
        $l = strlen($data);
        for ($i = 0; $i < $l; $i += 11) {
            $chunk = substr($data, $i, 11);
            $outlen = floor((strlen($chunk) * 6)/8); //6bit/char in, 8bits/char out, round down
            $y = gmp_strval(gmp_init(ltrim($chunk, '0'), 62), 16); //gmp doesn't like leading 0s
            $pad = str_pad($y, $outlen * 2, '0', STR_PAD_LEFT); //double output length as as we're going via hex (4bits/char)
            $outstring .= pack('H*', $pad); //same as hex2bin
        }
        return $outstring;
    }
	
    # encode with gzip and encrypt
    # Xenxin@Pbtt, Thu, 8 Dec 2016 10:46:18 +0800
    public static function encodeZex($data) {
        $str = '';
        $pad62zex = self::pad62zex;
        $str = gzcompress($data, 9);
        $str = self::encryptXor($str);
        $str = Base62x::encode($str);
        $data = null;
        return $pad62zex.$str;
    }
    
    # decode with gunzip and decrypt
    # Xenxin@Pbtt, Thu, 8 Dec 2016 10:48:28 +0800
    public static function decodeZex($data) {
        $str = '';
        $str = str_replace(self::pad62zex, '', $data);
        $str = Base62x::decode($str);
        $str = self::encryptXor($str, $dec=true);
        $str = gzuncompress($str);
        $data = null;
        return $str;
    }
    
	//-
	//- pack an array to string by using base62x and gz
	//- work with b62xUnpack
    //- Xenxin@Pbtt, Thu, 13 Oct 2016 14:23:56 +0800
    //- update with encrypt, Thu, 8 Dec 2016 10:54:05 +0800
    public static function b62xPack($arr){
        $str = '';
        $str = json_encode($arr);
        $str = gzcompress($str, 9);
        $str = self::encryptXor($str);
        $str = Base62x::encode($str);
        $arr = null;
        return self::pad62x.$str;
    }
    
    //-
    //- unpack a string to array using base62x and gz
	//- work with b62xPack
	//- update with decrypt, Thu, 8 Dec 2016 10:55:54 +0800
    public static function b62xUnpack($str){
        $arr = array();
		$str = str_replace(self::pad62x, '', $str);
        $str = Base62x::decode($str);
        $str = self::encryptXor($str, $dec=true);
        $str = gzuncompress($str);
        $arr = json_decode($str,true);
        $str = null;
        return $arr;
    }

    //- encrypt with xor
    //- Xenxin@Pbtt, Wed, 7 Dec 2016 14:53:28 +0800
    private static function encryptXor($str, $dec=false){
        $rtn = '';
        $arr = str_split($str);
        $arr2 = array();
        $l = count($arr);
        $k = ''; $pk = ord('a');
        if(!$dec){
            $k = $arr[0];
            for($i=1; $i<$l; $i++){
                $arr2[] = $arr[$i] ^ $k;
                # xor with first byte and then
                # append the byte at the end of new
            }
            $arr2[] = $k;
        }
        else{
            $l--;
            $k = $arr[$l];
            $arr2[] = $k;
            for($i=0; $i<$l; $i++){
                $arr2[] = $arr[$i] ^ $k; # xor
            }
        }
        $arr = null;
        $rtn = implode('', $arr2);
        return $rtn;
    }
    
}
?>
