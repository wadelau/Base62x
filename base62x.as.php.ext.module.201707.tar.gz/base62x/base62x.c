/*
  +----------------------------------------------------------------------+
  | Base62x with PHP Version 7                                           |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2016 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: wadelau@{ufqi,hotmail,gmail}.com                             |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_base62x.h"

/* If you declare any globals in php_base62x.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(base62x)
*/

/* True global resources - no need for thread safety here */
static int le_base62x;

//- self variables
static const char xtag = 'x';
static const char *enc = "-enc";
static const char *dec = "-dec";
static const char *deg = "-v";
static const char *cvtn = "-n";
static const char b62x[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwyz123x";
static const int bpos = 60; /* 0-60 chars */
static const int xpos = 64; /* b62x[64] = 'x' */
static const int ascmax = 127;
static const char asclist[] = "4567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwyz";
static const int max_safe_base = 36;
static const float ver = 0.9; // Mon Dec 12 19:33:18 CST 2016

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("base62x.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_base62x_globals, base62x_globals)
    STD_PHP_INI_ENTRY("base62x.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_base62x_globals, base62x_globals)
PHP_INI_END()
*/
/* }}} */

/* Remove the following function when you have successfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

/* Every user-visible function in PHP should document itself in the source */
/* {{{ proto string confirm_base62x_compiled(string arg)
   Return a string to confirm that the module is compiled in */
PHP_FUNCTION(confirm_base62x_compiled)
{
	char *arg = NULL;
	size_t arg_len, len;
	zend_string *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &arg, &arg_len) == FAILURE) {
		return;
	}

	strg = strpprintf(0, "Congratulations! You have successfully modified ext/%.78s/config.m4. Module %.78s is now compiled into PHP.", "base62x", arg);

	RETURN_STR(strg);
}
// self-defined func
PHP_FUNCTION(base62x_encode){
	char *arg = NULL;
	size_t arg_len, len;
	zend_string *strg;
	//char *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &arg, &arg_len) == FAILURE) {
		return;
	}
	//- bgn
	int i = 0;
	int isdebug = 1;
	int codetype = 0; //- 0:encode; 1: decode
    unsigned char rb62x[xpos*2]; /* reverse in decode block */
    int bint[xpos]; /* special handling for x1, x2, x3 *1 */
    int ascidx[ascmax+1];
    int ascrlist[ascmax+1]; 
	
	unsigned char *input = arg; //argv[argc-1]; // src from command line
	char *code =  ""; //argv[1];
	int asctype = 0; // for ascii 
	int issetv = 0;
	int issetn = 0;
	int fbase = 36;
	int m = 0;
	int inputlen = arg_len; // strlen(input);
	int arrsize = (int)inputlen * 2; //log(fbase) / log(xpos) + 1;  
	unsigned char output[arrsize]; //*output[ arrsize ] 

	if(issetn == 1 || codetype == 1){
		for(i=0; i<=xpos; i++){
			if( i>bpos && i<xpos){
				//--omit x1, x2, x3
			}
			else{
				rb62x[b62x[i]] = i;
			}
		}
	}
	/*
	if(isdebug){
		printf("ver:[%.2f], input length:[%d], output-len:[%d]\n", ver, inputlen, arrsize);
		for( i=0; i<inputlen; i++){
			printf("    --n:[%d] [%d] [%c]\n", i, input[i], input[i]);
		}
	}
	*/
	int remaini = 0; 
	i = 0;
	if(codetype==0){
		/* try to encode.... */
		if(asctype == 1){
		  //- for ascii
			do{
				if(ascidx[input[i]] > -1){
					output[m]=xtag;output[++m]=ascidx[input[i]];    
				}
				else if(input[i] == xtag){
					output[m]=xtag;output[++m]=xtag;    
				}
				else{
					output[m] = input[i];    
				}
				m++;
			}
			while(++i < inputlen);    
			output[m++] = xtag; // asctype has a tag 'x' appended
	   }
	   else{
			//- for non-ascii
		   int c0=0; int c1=0; int c2=0; int c3=0;
		   do{
			   remaini = inputlen - i; 
			   switch( remaini){
				   case 1:
					   c0 = input[i] >> 2;
					   c1 = ( ( (input[i] << 6) & 0xff ) >> 6 );
					   if( c0>bpos){ output[m]=xtag; output[++m]=b62x[c0]; }
					   else{ output[m]=b62x[c0]; }
					   if( c1>bpos){ output[++m]=xtag; output[++m]=b62x[c1]; }
					   else{ output[++m]=b62x[c1]; }
					   break;

				   case 2:
					   c0 = input[i] >> 2;
					   c1 = ( ((input[i] << 6) & 0xff) >> 2 ) | ( input[i+1] >> 4 );
					   c2 = ( ( (input[i+1] << 4) & 0xff ) >> 4 );
					   if( c0>bpos){ output[m]=xtag; output[++m]=b62x[c0]; }
					   else{ output[m]=b62x[c0]; }
					   if( c1>bpos){ output[++m]=xtag; output[++m]=b62x[c1]; }
					   else{ output[++m]=b62x[c1]; }
					   if( c2>bpos){ output[++m]=xtag; output[++m]=b62x[c2]; }
					   else{ output[++m]=b62x[c2]; }
					   i++;
					   break;

				   default:
					   c0 = input[i] >> 2;
					   c1 = ( ((input[i] << 6) & 0xff) >> 2 ) | ( input[i+1] >> 4 );
					   c2 = ( ((input[i+1] << 4) & 0xff ) >> 2) | ( (input[i+2] >> 6) );
					   c3 = ( (input[i+2] << 2) & 0xff) >> 2;
					   if( c0>bpos){ output[m]=xtag; output[++m]=b62x[c0]; }
					   else{ output[m]=b62x[c0]; }
					   if( c1>bpos){ output[++m]=xtag; output[++m]=b62x[c1]; }
					   else{ output[++m]=b62x[c1]; }
					   if( c2>bpos){ output[++m]=xtag; output[++m]=b62x[c2]; }
					   else{ output[++m]=b62x[c2]; }
					   if( c3>bpos){ output[++m]=xtag; output[++m]=b62x[c3]; }
					   else{ output[++m]=b62x[c3]; }
					   i+=2; 
				}
				m++;
			}
			while(++i < inputlen); 
		}
	}
	output[m] = '\0';
	/*
	int k = strlen(output);
	for(i=m; i<k; i++){
		output[i] = '\0';
	}
	if(isdebug){
		printf("\nOutput:[%s]\n", output);
		for( i=0; i<m; i++){
			printf("  ---i:[%d] char:[%c] val:[%d]\n", i, output[i], output[i]);
		}
	}
	*/
	// end
	strg = strpprintf(0, "%s", output);
	/*
	 * for PHP 5.x
	strg = (char*) safe_emalloc(m, sizeof(char), 1);
	memcpy(strg, output, m);
	*(strg+m) = '\0';

	#if ZEND_MODULE_API_NO >= 20151012
		RETURN_STRING(strg);
	#else
		RETURN_STRING(strg,0);
	#endif
	*/
	RETURN_STR(strg);
}
// self-defined func
PHP_FUNCTION(base62x_decode){
	char *arg = NULL;
	size_t arg_len, len;
	zend_string *strg;
	//char *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &arg, &arg_len) == FAILURE) {
		return;
	}
	//- bgn
	int i = 0;
	int isdebug = 1;
	int codetype = 1; //- 0:encode; 1: decode
    unsigned char rb62x[xpos*2]; /* reverse in decode block */
    int bint[xpos]; /* special handling for x1, x2, x3 *1 */
    int ascidx[ascmax+1];
    int ascrlist[ascmax+1]; 

	unsigned char *input = arg; //argv[argc-1]; // src from command line
	char *code =  ""; //argv[1];
	int asctype = 0; // for ascii 
	int issetv = 0;
	int issetn = 0;
	int fbase = 36;
	int m = 0;
	int inputlen = arg_len; // strlen(input);
	int arrsize = (int)inputlen * 2; // log(fbase) / log(xpos) + 1;  
	unsigned char output[arrsize]; //*output[ arrsize ] 

	if(issetn == 1 || codetype == 1){ //-  
		for(i=0; i<=xpos; i++){
			if(i>bpos && i<xpos){
				//--omit x1, x2, x3
			}
			else{
				rb62x[b62x[i]] = i;
			}
		}
	}
	/*	
	if(isdebug){
		printf("ver:[%.2f], input length:[%d], output-len:[%d]\n", ver, inputlen, arrsize);
		for( i=0; i<inputlen; i++){
			printf("    --n:[%d] [%d] [%c]\n", i, input[i], input[i]);
		}
	}
	*/
	int remaini = 0;
	i = 0;
	if(codetype == 1){
		/* try to decode.... */
		if(asctype == 1){
			//- for ascii
			inputlen--;
			do{
				if(input[i] == xtag){
					if( input[i+1] == xtag){
						output[m] = xtag;      
						i++;
					}
					else{
					  output[m]=ascrlist[input[++i]];    
					}
				}
				else{
					output[m] = input[i];    
				}
				m++;
			}
			while(++i < inputlen);  
		}
		else{
			//- for non-ascii
			int c0=0; int c1=0; int c2=0; int k=0; 
			unsigned char tmpin[4];
			bint['1']=1; bint['2']=2; bint['3']=3; /* special handling with x1, x2, x3 *2 */
			int maxidx = inputlen - 1; int last8 = inputlen - 8;
			do{
				char tmpin[4]={'\0','\0','\0','\0'};
				remaini = inputlen - i;
				k=0;
				switch(remaini){
					case 1:
						printf("Base62x.decode: found illegal base62x input:[%s]! 1612121816.\n", input);
						break;

					case 2:
						if( input[i]==xtag){ tmpin[0] = bpos+bint[input[++i]]; }
						else{ tmpin[0]=rb62x[input[i]]; }
						if(i == maxidx){ //- may be wrapped into a func decode_by_length
							c0 = (tmpin[0] << 2);	
							output[m]=c0;
						}
						else{
							if( input[++i]==xtag){ tmpin[1] = bpos+bint[input[++i]]; }
							else{ tmpin[1]=rb62x[input[i]]; }
							c0 = tmpin[0] << 2 | tmpin[1]; 
							output[m]=c0;
						}
						break;

					case 3:
						if( input[i]==xtag){ tmpin[0] = bpos+bint[input[++i]]; }
						else{ tmpin[0]=rb62x[input[i]]; }
						if( input[++i]==xtag){ tmpin[1] = bpos+bint[input[++i]]; }
						else{ tmpin[1]=rb62x[input[i]]; }
						if(i == maxidx){
							c0 = tmpin[0] << 2 | tmpin[1]; 
							output[m]=c0;
						}
						else{
							if( input[++i]==xtag){ tmpin[2] = bpos+bint[input[++i]]; }
							else{ tmpin[2]=rb62x[input[i]]; }
							c0 = tmpin[0] << 2 | tmpin[1] >> 4; 
							c1 = ( ( tmpin[1] << 4) & 0xf0) | tmpin[2];
							output[m]=c0;
							output[++m]=c1;
						}
						break;

					default:
						if(i < last8){
							if( input[i]==xtag){ tmpin[0] = bpos+bint[input[++i]]; }
							else{ tmpin[0]=rb62x[input[i]]; }
							if( input[++i]==xtag){ tmpin[1] = bpos+bint[input[++i]]; }
							else{ tmpin[1]=rb62x[input[i]]; }
							if( input[++i]==xtag){ tmpin[2] = bpos+bint[input[++i]]; }
							else{ tmpin[2]=rb62x[input[i]]; }
							if( input[++i]==xtag){ tmpin[3] = bpos+bint[input[++i]]; }
							else{ tmpin[3]=rb62x[input[i]]; }
							c0 = tmpin[0] << 2 | tmpin[1] >> 4; 
							c1 = ( ( tmpin[1] << 4) & 0xf0) | ( tmpin[2] >> 2 );
							c2 = ( ( tmpin[2] << 6) & 0xff) | tmpin[3];
							output[m]=c0;
							output[++m]=c1;
							output[++m]=c2;							
						}
						else{
							if( input[i]==xtag){ tmpin[0] = bpos+bint[input[++i]]; }
							else{ tmpin[0]=rb62x[input[i]]; }
							if( input[++i]==xtag){ tmpin[1] = bpos+bint[input[++i]]; }
							else{ tmpin[1]=rb62x[input[i]]; }
							if(i == maxidx){
								c0 = tmpin[0] << 2 | tmpin[1]; 
								output[m]=c0;
							}
							else{
								if( input[++i]==xtag){ tmpin[2] = bpos+bint[input[++i]]; }
								else{ tmpin[2]=rb62x[input[i]]; }
								if(i == maxidx){
									c0 = tmpin[0] << 2 | tmpin[1] >> 4; 
									c1 = ( ( tmpin[1] << 4) & 0xf0) | tmpin[2];
									output[m]=c0;
									output[++m]=c1;
								}
								else{
									if( input[++i]==xtag){ tmpin[3] = bpos+bint[input[++i]]; }
									else{ tmpin[3]=rb62x[input[i]]; }
									c0 = tmpin[0] << 2 | tmpin[1] >> 4; 
									c1 = ( ( tmpin[1] << 4) & 0xf0) | ( tmpin[2] >> 2 );
									c2 = ( ( tmpin[2] << 6) & 0xff) | tmpin[3];
									output[m]=c0;
									output[++m]=c1;
									output[++m]=c2;
								}
							}
						}
				}
				m++;
			}
			while(++i < inputlen);
		}
	}
	output[m] = '\0';
	/*
	int k = strlen(output);
	for(i=m; i<k; i++){
		output[i] = '\0';
	}	
	if(isdebug){
		printf("\nOutput:[%s]\n", output);
		for( i=0; i<m; i++){
			printf("  ---i:[%d] char:[%c] val:[%d]\n", i, output[i], output[i]);
		}
	}
	*/
	//- avoid \0 in outout
	strg = zend_string_alloc(m, 0);
	for(i=0; i<m; i++){
		/*
		if(output[i] == '\0'){
			printf(" ---i:[%d] char:[%c] val:[%d] not end.\n", i, output[i], output[i]);		
		}
		*/
		ZSTR_VAL(strg)[i] = output[i];
	}
	ZSTR_LEN(strg) = m;
	ZSTR_VAL(strg)[ZSTR_LEN(strg)] = '\0';
	//- end
	//strg = strpprintf(0, "%s", output); // arg
	/*
	 * for PHP 5.x
	strg = (char*) safe_emalloc(m, sizeof(char), 1);
	memcpy(strg, output, m);
	*(strg+m) = '\0';
	#if ZEND_MODULE_API_NO >= 20151012
		RETURN_STRING(strg);
	#else
		RETURN_STRING(strg,0);
	#endif
	*/
	RETURN_STR(strg);
}
/* }}} */
/* The previous line is meant for vim and emacs, so it can correctly fold and
   unfold functions in source code. See the corresponding marks just before
   function definition, where the functions purpose is also documented. Please
   follow this convention for the convenience of others editing your code.
*/


/* {{{ php_base62x_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_base62x_init_globals(zend_base62x_globals *base62x_globals)
{
	base62x_globals->global_value = 0;
	base62x_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(base62x)
{
	/* If you have INI entries, uncomment these lines
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(base62x)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(base62x)
{
#if defined(COMPILE_DL_BASE62X) && defined(ZTS)
	ZEND_TSRMLS_CACHE_UPDATE();
#endif
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(base62x)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(base62x)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "base62x support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */

/* {{{ base62x_functions[]
 *
 * Every user visible function must have an entry in base62x_functions[].
 */
const zend_function_entry base62x_functions[] = {
	PHP_FE(confirm_base62x_compiled,	NULL)		/* For testing, remove later. */
	PHP_FE(base62x_encode, NULL)
	PHP_FE(base62x_decode, NULL)
	PHP_FE_END	/* Must be the last line in base62x_functions[] */
};
/* }}} */

/* {{{ base62x_module_entry
 */
zend_module_entry base62x_module_entry = {
	STANDARD_MODULE_HEADER,
	"base62x",
	base62x_functions,
	PHP_MINIT(base62x),
	PHP_MSHUTDOWN(base62x),
	PHP_RINIT(base62x),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(base62x),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(base62x),
	PHP_BASE62X_VERSION,
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_BASE62X
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
#endif
ZEND_GET_MODULE(base62x)
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
