
#
# Xenxin@Ufqi.com
# Mon Jul 10 21:18:29 CST 2017
# try to install base62x as php ext.
#
# download this .tar.gz
# extract and rename as ./ext/base62x

# rm configure
# ./buildconf --force
# add --enable-base62x in configure
#

# ./congifure & make & make install
#
