<?php

include_once("base62x.class.php");
include_once("class.base62withgmp.php");


$b62x = new Base62x();

$s = "union:d=23656762a1f8baca2df5cd02fc6473a3;ci:A4984;oi:ou_12418875;nt:IN;ai:95bbcfc052ab5129;price:0.50000;union:OU_uc2_mariana;gaid:a0636a88-6d9e-404a-9dd6-746704b65802;"; #rand(1000, 999999).'abcd1234'.rand(1000, 999999);
$s1 = Base62::encode($s);
#$s2 = Base62x::encode($s);
$s2 = gzcompress($s);
$s2 = $b62x->encode($s2);
$s3 = base62x_encode($s);

print "s:$s\ns1:$s1 s1len:".($s1l=strlen($s1))."\ns2:$s2 s2len:".($s2l=strlen($s2))." balance-s1-v2:".($s1l-$s2l)."\n";
print "s3:$s3 s3len:".($s3l=strlen($s3))."\n";

# test for speed
$n = 10000;
$j = 1000;
$time_bgn = microtime_float();
for($i=0; $i<$n; $i++){
	$s = rand(1000, 999999).'abcd中文'.rand(1000,999999).'1234'.rand(1000, 999999);
	#$s1 = Base62x::encode($s);
	$s1 = $b62x->encode($s);
}
$time_end = microtime_float();
print "\tBase62x-class-script time cost t1:".($t1=$time_end-$time_bgn)."\n"; #." s1l:$s1l s2l:$s2l balance:".($slb=$s2l-$s1l)." p:".($slb/$n)."\n";

$time_bgn = microtime_float();
for($i=0; $i<$n; $i++){
	$s = rand(1000, 999999).'abcd中文'.rand(1000,999999).'1234'.rand(1000, 999999);
	$s1 = base62x_encode($s);
	#$s2 = base62x_decode($s1);
	#if($i%$j == 0){ print $s."\t".$s1." s2:$s2\n"; }
}
$time_end = microtime_float();
print "\tBase62x-built-in time cost t2:".($t2=$time_end-$time_bgn)."\n";

$time_bgn = microtime_float();
for($i=0; $i<$n; $i++){
	$s = rand(1000, 999999).'abcd中文'.rand(1000,999999).'1234'.rand(1000, 999999);
	$s1 = Base62::encode($s);
	#if($i%$j == 0){ print $s."\t".$s1."\n"; }
}
$time_end = microtime_float();
print "\tBase62-gmp time cost t3:".($t3=$time_end-$time_bgn)."\n";

print "t1:$t1 t2:$t2 balance-t1-t2:".($t4=$t2-$t1)." perc:".($t4/$t2)."\n";
print "t2:$t2 t3:$t3 balance-t2-t3:".($t5=$t3-$t2)." perc:".($t5/$t3)."\n";
print "t1:$t1 t3:$t3 balance-t1-t3:".($t6=$t3-$t1)." perc:".($t6/$t3)."\n";

# test for cross-language operations
$matched  = 0; $unmatched = 0;
for($i=0; $i<$n; $i++){
	$s = rand(1000, 999999).'abcd中文'.rand(1000,999999).'1234'.rand(1000, 999999);
	$s0 = gzcompress($s);
	$s1 = $b62x->encode($s0);
	$s2 = base62x_decode($s1);
	$s2 = gzuncompress($s2);
	if($i%$j == 0){ print "$s $s1 $s2\n"; }
	if($s2 == $s){
		$matched++;	
	}
	else{
		$unmatched++;	
	}
}
print "$n $matched $unmatched\n";

# test for base64
$s = "omW0Q3a6SHR4qGNZz0DnohoYlHprCxy9eQFYORG6gekAfwDLItPcbywlpSvkjz3avGgszw07DNImtlkKTsLa//3jKeMR+fiYb78NqAYbSUIyh+52hJHuc7lxZXiIhIePP+JBxd3jLJnv4KpQv5hnBCBfpXg=";
$s1 = base64_decode($s);
$s2 = base62x_encode($s1);
$s3 = base62x_decode($s2);
print "s:$s\ns1:$s1 ".strlen($s1)."\ns2:$s2\ns3:$s3 ".strlen($s3)."\n";
print "s3==s1:".($s3==$s1)."\n\n\n";

# test for non-printable chars
$s = "";
$l = 50;
$sn = "";
for($i=0; $i<$l; $i++){
	$n = rand(0, 255);
	$s .= chr($n);
	$sn .= " ".$n;
}
print "sn: $sn\n";

#$s = "1234".chr(0)."5678".rand(10,99);

$s1 = $b62x->encode($s);
$s2 = $b62x->decode($s1);
var_dump($s);
var_dump($s1);
var_dump($s2);
print "base62x-class-script: $s $s1 $s2\n";
print "s2==s:".($s2==$s)."\n\n";


$s1 = base62x_encode($s);
$s2 = base62x_decode($s1);
var_dump($s);
var_dump($s1);
var_dump($s2);
print "base62x-built-in: $s $s1 $s2\n";
print "s2==s:".($s2==$s)."\n\n";

$s1 = Base62::encode($s);
$s2 = base62::decode($s1);
var_dump($s);
var_dump($s1);
var_dump($s2);
print "base62-with-gmp: $s $s1 $s2\n";
print "s2==s:".($s2==$s)."\n\n";

# funcs
function microtime_float(){
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}

?>
